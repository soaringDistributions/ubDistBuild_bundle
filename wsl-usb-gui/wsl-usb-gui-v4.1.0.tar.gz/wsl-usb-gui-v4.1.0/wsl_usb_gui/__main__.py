import asyncio
from . import gui

gui.main()
