﻿// SPDX-FileCopyrightText: 2022 Frans van Dorsselaer
//
// SPDX-License-Identifier: GPL-3.0-only

[assembly: Parallelize(Scope = ExecutionScope.MethodLevel)]
[assembly: DiscoverInternals]
