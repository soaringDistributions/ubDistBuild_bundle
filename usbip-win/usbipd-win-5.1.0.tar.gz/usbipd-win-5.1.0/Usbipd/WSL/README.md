<!--
SPDX-FileCopyrightText: 2023 Frans van Dorsselaer

SPDX-License-Identifier: GPL-3.0-only
-->

# WSL binaries

The `usbip` binaries were built using the helper project [`usbipd-win-wsl`](https://github.com/dorssel/usbipd-win-wsl).

The `usbip-auto-attach` binaries were built using the helper project
[`usbip-auto-attach`](https://github.com/andrewleech/usbip-auto-attach) by [Andrew Leech](https://github.com/andrewleech).
