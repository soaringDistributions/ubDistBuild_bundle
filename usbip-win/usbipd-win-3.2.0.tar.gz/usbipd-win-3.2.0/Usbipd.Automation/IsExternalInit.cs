﻿// SPDX-FileCopyrightText: 2022 Frans van Dorsselaer
//
// SPDX-License-Identifier: GPL-3.0-only

namespace System.Runtime.CompilerServices;

/// <summary>
/// Fix for using C# 9 feature in netstandard2.0.
/// </summary>
static class IsExternalInit
{
}
