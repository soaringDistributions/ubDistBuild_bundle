﻿// SPDX-FileCopyrightText: 2022 Frans van Dorsselaer
//
// SPDX-License-Identifier: GPL-3.0-only

global using Microsoft.VisualStudio.TestTools.UnitTesting;
global using Moq;
global using Usbipd;
