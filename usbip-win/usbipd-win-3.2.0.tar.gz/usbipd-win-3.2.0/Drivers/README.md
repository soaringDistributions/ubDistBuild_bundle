<!--
SPDX-FileCopyrightText: 2020 Frans van Dorsselaer

SPDX-License-Identifier: GPL-3.0-only
-->

# Declaration of License Compliance

These drivers are from a binary distribution of VirtualBox, version 7.0.10, provided
by Oracle Corporation, subject to the terms and conditions of the
[GNU General Public License, version 3](https://www.gnu.org/licenses/gpl-3.0.html).

With the binary distribution came a written offer to download the source code from
<https://download.virtualbox.org/virtualbox/>.

This README is to conform to clause 6c of the license.
